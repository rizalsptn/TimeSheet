// components/TaskModal.tsx

import { useEffect, useState } from "react";
import { X } from "lucide-react";
import TaskEditForm from "./taskeditform";

interface Task {
  id: number;
  user_id: number;
  name: string;
  task_date: string;
  from_time: string;
  until_time: string;
  description: string;
  created: string;
  modified: string;
}

interface TaskModalProps {
  taskId: number | null;
  onClose: () => void;
}

export default function TaskModal({ taskId, onClose }: TaskModalProps) {
  const [task, setTask] = useState<Task | null>(null);
  const [loading, setLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [form, setForm] = useState({
    name: "",
    task_date: "",
    from_time: "",
    until_time: "",
    description: "",
  });

  // Ambil data tugas saat modal dibuka
  useEffect(() => {
    if (!taskId) return;

    const fetchTask = async () => {
      setLoading(true);
      try {
        const response = await fetch(`http://localhost:3001/tasks_single/${taskId}`);
        const data = await response.json();
        setTask(data);
        setForm({
          name: data.name,
          task_date: data.task_date.slice(0, 10),
          from_time: data.from_time,
          until_time: data.until_time,
          description: data.description || "",
        });
      } catch (error) {
        console.error("Gagal mengambil data tugas:", error);
      }
      setLoading(false);
    };

    fetchTask();
  }, [taskId]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleUpdate = async () => {
    try {
      const res = await fetch(`http://localhost:3001/tasks/${taskId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(form),
      });
  
      if (!res.ok) throw new Error("Update gagal");
  
      alert("Berhasil diperbarui");
      setIsEditing(false);
    } catch (err) {
      alert("Gagal update data");
      console.error(err);
    }
  };  

  const handleDelete = async () => {
    const confirmDelete = confirm("Yakin ingin menghapus?");
    if (!confirmDelete || !task) return;

    try {
      const res = await fetch(`http://localhost:3001/tasks/${task.id}`, {
        method: "DELETE",
        credentials: "include",
      });
      if (!res.ok) throw new Error("Gagal hapus");
      alert("Berhasil dihapus");
      onClose();
    } catch (err) {
      alert("Gagal menghapus tugas");
    }
  };

  if (!taskId || !task) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96 relative">
        <div className="flex justify-between items-center border-b pb-2">
          <h2 className="text-lg font-semibold">Detail Tugas</h2>
          <button onClick={onClose}>
            <X className="w-5 h-5 text-gray-600 hover:text-red-500" />
          </button>
        </div>

        {loading ? (
          <p className="mt-4">Memuat data...</p>
        ) : (
          <div className="mt-4 space-y-2">
            {isEditing ? (
              <TaskEditForm form={form} onChange={handleChange} />
            ) : (
              <>
                <p><strong>Nama:</strong> {task.name}</p>
                <p><strong>Tanggal Tugas:</strong> {new Date(task.task_date).toLocaleDateString()}</p>
                <p><strong>Waktu Mulai:</strong> {task.from_time}</p>
                <p><strong>Waktu Selesai:</strong> {task.until_time}</p>
                <p><strong>Deskripsi:</strong> {task.description || "Tidak ada deskripsi"}</p>
                <p><strong>Dibuat:</strong> {new Date(task.created).toLocaleString()}</p>
                <p><strong>Diubah:</strong> {new Date(task.modified).toLocaleString()}</p>
              </>
            )}
          </div>
        )}

        <div className="mt-4 flex justify-end space-x-2">
          {isEditing ? (
            <>
              <button
                onClick={handleUpdate}
                className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
              >
                Simpan
              </button>
              <button
                onClick={() => setIsEditing(false)}
                className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
              >
                Batal
              </button>
            </>
          ) : (
            <>
              <button
                onClick={() => setIsEditing(true)}
                className="bg-yellow-500 text-white px-4 py-2 rounded hover:bg-yellow-600"
              >
                Edit
              </button>
              <button
                onClick={handleDelete}
                className="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600"
              >
                Delete
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
