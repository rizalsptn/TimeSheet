export { default as main } from './main.svg'; 
export { default as vimeo } from './vimeo.svg'; 
