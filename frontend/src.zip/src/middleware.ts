import { NextRequest, NextResponse } from "next/server";
import { verifyRefreshToken } from "@/lib/Auth";

export async function middleware(req: NextRequest) {
  const token = req.cookies.get("refreshToken")?.value;

  const isValid = await verifyRefreshToken(token);

  if (!isValid) {
    return NextResponse.redirect(new URL("/auth/sign-in", req.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!auth).*)"],
};