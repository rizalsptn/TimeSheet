"use client";

import { useEffect, useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui-elements/button";
import { Eye } from "lucide-react";
import TaskModal from "./TaskModal"; // Import modal

// ✅ Definisi tipe data Task
interface Task {
  id: number;
  name: string;
  description: string;
}

export default function TaskTable() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedTaskId, setSelectedTaskId] = useState<number | null>(null);

  useEffect(() => {
    fetchTasks();
  }, []);

  // ✅ Ambil data tugas dari API
  const fetchTasks = async () => {
    setLoading(true);
    try {
      const response = await fetch("http://localhost:3001/tasks");
      const data = await response.json();
      setTasks(data);
    } catch (error) {
      console.error("Gagal mengambil data tugas:", error);
    }
    setLoading(false);
  };

  return (
    <div className="rounded-lg bg-white p-6 shadow-md">
      {/* Loading Indicator */}
      {loading ? (
        <p>Loading...</p>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-16">No</TableHead>
              <TableHead>Nama Tugas</TableHead>
              <TableHead>Deskripsi</TableHead>
              <TableHead className="w-24 text-center">Aksi</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {tasks.map((task, index) => (
              <TableRow key={task.id}>
                <TableCell>{index + 1}</TableCell>
                <TableCell>{task.name}</TableCell>
                <TableCell>{task.description || "Tidak ada deskripsi"}</TableCell>
                <TableCell className="text-center">
                  <Button
                    variant="outlineDark"
                    size="small"
                    onClick={() => setSelectedTaskId(task.id)}
                  >
                    <Eye className="w-5 h-5" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}

      {/* Modal View */}
      {selectedTaskId && (
        <TaskModal taskId={selectedTaskId} onClose={() => setSelectedTaskId(null)} />
      )}
    </div>
  );
}
