import { useEffect, useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui-elements/button";

// ✅ Definisi tipe data Task
interface Task {
  id: number;
  user_id: number;
  name: string;
  task_date: string;
  from_time: string;
  until_time: string;
  description: string;
  created: string;
  modified: string;
}

interface TaskModalProps {
  taskId: number | null;
  onClose: () => void;
}

export default function TaskModal({ taskId, onClose }: TaskModalProps) {
  const [task, setTask] = useState<Task | null>(null);
  const [loading, setLoading] = useState(false);

  // ✅ Ambil data tugas berdasarkan ID saat modal terbuka
  useEffect(() => {
    if (!taskId) return;

    const fetchTask = async () => {
      setLoading(true);
      try {
        const response = await fetch(`http://localhost:3001/tasks/${taskId}`);
        const data = await response.json();
        setTask(data);
      } catch (error) {
        console.error("Gagal mengambil data tugas:", error);
      }
      setLoading(false);
    };

    fetchTask();
  }, [taskId]);

  if (!taskId || !task) return null;

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96">
        {/* Header Modal */}
        <div className="flex justify-between items-center border-b pb-2">
          <h2 className="text-lg font-semibold">Detail Tugas</h2>
          <button onClick={onClose}>
            <X className="w-5 h-5 text-gray-600 hover:text-red-500" />
          </button>
        </div>

        {/* Loading */}
        {loading ? (
          <p className="mt-4">Memuat data...</p>
        ) : (
          <div className="mt-4 space-y-2">
            <p><strong>ID:</strong> {task.id}</p>
            <p><strong>User ID:</strong> {task.user_id}</p>
            <p><strong>Nama:</strong> {task.name}</p>
            <p><strong>Tanggal Tugas:</strong> {new Date(task.task_date).toLocaleDateString()}</p>
            <p><strong>Waktu Mulai:</strong> {new Date(task.from_time).toLocaleTimeString()}</p>
            <p><strong>Waktu Selesai:</strong> {new Date(task.until_time).toLocaleTimeString()}</p>
            <p><strong>Deskripsi:</strong> {task.description || "Tidak ada deskripsi"}</p>
            <p><strong>Dibuat:</strong> {new Date(task.created).toLocaleString()}</p>
            <p><strong>Diubah:</strong> {new Date(task.modified).toLocaleString()}</p>
          </div>
        )}

        {/* Tombol Tutup */}
        <div className="mt-4 flex justify-end">
          <Button variant="outlineDark" size="small" onClick={onClose}>
            Tutup
          </Button>
        </div>
      </div>
    </div>
  );
}
