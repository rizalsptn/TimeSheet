"use client";

import { useState } from "react";

const TaskForm = () => {
  const [formData, setFormData] = useState({
    user_id: "",
    name: "",
    task_date: "",
    from_time: "",
    until_time: "",
    description: "",   
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    try {
      const response = await fetch("http://localhost:3001/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Gagal menyimpan tugas");
      }

      alert("Tugas berhasil disimpan!");
      setFormData({
        user_id: "",
        name: "",
        task_date: "",
        from_time: "",
        until_time: "",
        description: "",
      });
    } catch (error) {
      console.error(error);
      alert("Terjadi kesalahan saat menyimpan tugas.");
    }
  };

  return (
    <form onSubmit={handleSubmit} className="max-w-lg mx-auto bg-white p-6 rounded-lg shadow-md">
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">Nama Pekerjaan</label>
        <input
          type="text"
          name="name"
          value={formData.name}
          onChange={handleChange}
          className="w-full border border-gray-300 p-2 rounded"
          required
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">Tanggal</label>
        <input
          type="date"
          name="task_date"
          value={formData.task_date}
          onChange={handleChange}
          className="w-full border border-gray-300 p-2 rounded"
          required
        />
      </div>

      <div className="mb-4 flex space-x-4">
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">Waktu Mulai</label>
          <input
            type="time"
            name="from_time"
            value={formData.from_time}
            onChange={handleChange}
            className="border border-gray-300 p-2 rounded"
            required
          />
        </div>
        <div>
          <label className="block text-gray-700 text-sm font-bold mb-2">Waktu Selesai</label>
          <input
            type="time"
            name="until_time"
            value={formData.until_time}
            onChange={handleChange}
            className="border border-gray-300 p-2 rounded"
            required
          />
        </div>
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">Keterangan</label>
        <textarea
          name="description"
          value={formData.description}
          onChange={handleChange}
          className="w-full border border-gray-300 p-2 rounded"
        />
      </div>

      <div className="flex justify-between">
        <button
          type="submit"
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Simpan
        </button>
        <button
          type="button"
          onClick={() =>
            setFormData({
              user_id: "",
              name: "",
              task_date: "",
              from_time: "",
              until_time: "",
              description: "",
            })
          }
          className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
        >
          Batal
        </button>
      </div>
    </form>
  );
};

export default TaskForm;
