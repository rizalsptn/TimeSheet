"use client";

import { useRouter } from "next/navigation";
import axios from "axios";

const SignOut = () => {
  const router = useRouter();

  const handleSignOut = async () => {
    try {
      await axios.post("/api/auth/logout", {}, { withCredentials: true });
      router.push("/login"); // Redirect ke halaman login setelah logout
    } catch (error) {
      console.error("Error signing out: ", error);
    }
  };

  return (
    <button onClick={handleSignOut} className="p-2 bg-red-500 text-white rounded">
      Sign Out
    </button>
  );
};

export default SignOut;
