import { prisma } from "@/lib/prisma";

export async function verifyRefreshToken(token?: string) {
  if (!token) return false;

  const tokenInDB = await prisma.logins.findFirst({
    where: { refresh_token: token },
  });

  return !!tokenInDB;
}